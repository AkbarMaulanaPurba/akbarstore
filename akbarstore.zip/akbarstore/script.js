function eror(){
Swal.fire({
  title: "Error:",
  text: "Fitur Ini Belum Tersedia:(",
  icon: "error"
});
}